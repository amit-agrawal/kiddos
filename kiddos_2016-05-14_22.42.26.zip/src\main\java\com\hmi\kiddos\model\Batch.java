package com.hmi.kiddos.model;

public enum Batch {
    MORNING_A, MORNING_B, MORNING_C, NOON_A, NOON_B, NOON_C 
}
