package com.hmi.kiddos.model;
import org.junit.Test;
import org.springframework.roo.addon.test.annotations.RooIntegrationTest;

@RooIntegrationTest(entity = Program.class)
public class ProgramIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
