package com.hmi.kiddos.model;

public enum ProgramTypes {
    PLAY_GROUP, NURSERY, JR_KG, ADMISSION_FEE, ANNUAL_FEE, DAY_CARE, SUMMERCAMP, ENRICHMENT_CLUB
}
