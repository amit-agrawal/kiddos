package com.hmi.kiddos.model;

public enum Department {

    Teacher, Nanny, Admin
}
