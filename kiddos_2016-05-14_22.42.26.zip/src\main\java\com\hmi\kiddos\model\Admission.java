package com.hmi.kiddos.model;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.apache.log4j.Logger;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.roo.addon.javabean.annotations.RooJavaBean;
import org.springframework.roo.addon.javabean.annotations.RooToString;
import org.springframework.roo.addon.jpa.annotations.activerecord.RooJpaActiveRecord;

@RooJavaBean
@RooToString
@RooJpaActiveRecord
public class Admission {

    private static Logger log = Logger.getLogger(Admission.class);

    @Transient
    private Integer feesExpected = 0;

    @Transient
    private Integer feesDue = 0;

    @Transient
    private Integer feesPaid = 0;

    public Integer getFeesExpected() {
        feesExpected = 0;
        if (!programs.isEmpty()) {
            boolean sc = false;
            for (Program program : programs) {
                feesExpected += program.getFees();
                if (program.getType().equals("Summer Camp")) sc = true;
            }
            if (sc) {
                log.info("adjusting fees for SC");
                if (feesExpected == 1900) feesExpected = 3800; else if (feesExpected == 5700) feesExpected = 5800; else if (feesExpected == 7600) feesExpected = 5800;
            }
        }
        log.info("Fees calculated: " + feesExpected + " , discount: " + discount);
        feesExpected = feesExpected - discount;
        return feesExpected;
    }

    public Integer getFeesPaid() {
        feesPaid = 0;
        log.debug("Payments are: " + payments);
        if (!payments.isEmpty()) {
            for (Payment payment : payments) {
                feesPaid += payment.getAmount();
            }
        }
        return feesPaid;
    }

    public Integer getFeesDue() {
        return getFeesExpected() - getFeesPaid();
    }

    /**
     */
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "M-")
    private Calendar admissionDate;

    /**
     */
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(style = "M-")
    private Calendar joiningDate;

    @ManyToOne(cascade = CascadeType.ALL)
    private Transportation transportArrival;

    @ManyToOne(cascade = CascadeType.ALL)
    private Transportation transportDeparture;

    /**
     */
    @Size(max = 400)
    private String notes;

    /**
     */
    @NotNull
    @ManyToOne
    private Child child;

    /**
     */
    @NotNull
    @ManyToMany(cascade = CascadeType.ALL)
    private Set<Program> programs = new HashSet<Program>();

    /**
     */
    @ManyToMany(cascade = CascadeType.ALL, mappedBy = "admissions")
    private Set<Payment> payments = new HashSet<Payment>();

    public String toString() {
        return child.toString() + ", " + programs.toString();
    }

    /**
     */
    private int discount;
}
