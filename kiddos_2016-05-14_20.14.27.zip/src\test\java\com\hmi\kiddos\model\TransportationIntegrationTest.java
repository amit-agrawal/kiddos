package com.hmi.kiddos.model;
import org.junit.Test;
import org.springframework.roo.addon.test.annotations.RooIntegrationTest;

@RooIntegrationTest(entity = Transportation.class)
public class TransportationIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
