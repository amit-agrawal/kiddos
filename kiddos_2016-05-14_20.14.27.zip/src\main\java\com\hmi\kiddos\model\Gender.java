package com.hmi.kiddos.model;

public enum Gender {
    Male, Female
}
