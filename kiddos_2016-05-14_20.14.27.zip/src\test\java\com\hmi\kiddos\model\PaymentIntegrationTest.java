package com.hmi.kiddos.model;
import org.junit.Test;
import org.springframework.roo.addon.test.annotations.RooIntegrationTest;

@RooIntegrationTest(entity = Payment.class)
public class PaymentIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
