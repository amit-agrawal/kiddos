package com.hmi.kiddos.model;

public enum PaymentMedium {

    CASH, CHEQUE, ONLINE
}
