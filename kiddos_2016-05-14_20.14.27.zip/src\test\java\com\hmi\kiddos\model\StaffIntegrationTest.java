package com.hmi.kiddos.model;
import org.junit.Test;
import org.springframework.roo.addon.test.annotations.RooIntegrationTest;

@RooIntegrationTest(entity = Staff.class)
public class StaffIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
