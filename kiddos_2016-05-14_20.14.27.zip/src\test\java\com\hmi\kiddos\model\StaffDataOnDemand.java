package com.hmi.kiddos.model;
import org.springframework.roo.addon.dod.annotations.RooDataOnDemand;

@RooDataOnDemand(entity = Staff.class)
public class StaffDataOnDemand {
}
