package com.hmi.kiddos.model;
import org.springframework.roo.addon.dod.annotations.RooDataOnDemand;

@RooDataOnDemand(entity = Payment.class)
public class PaymentDataOnDemand {
}
