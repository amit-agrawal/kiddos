package com.hmi.kiddos.model;

public enum PreSchoolTerms {

    Term_1_2016_17, Term_2_2016_17, Term_3_2016_17, Term_4_2016_17
}
