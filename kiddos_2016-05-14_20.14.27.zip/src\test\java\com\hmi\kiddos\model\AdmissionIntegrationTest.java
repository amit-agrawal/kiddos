package com.hmi.kiddos.model;
import org.junit.Test;
import org.springframework.roo.addon.test.annotations.RooIntegrationTest;

@RooIntegrationTest(entity = Admission.class)
public class AdmissionIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
